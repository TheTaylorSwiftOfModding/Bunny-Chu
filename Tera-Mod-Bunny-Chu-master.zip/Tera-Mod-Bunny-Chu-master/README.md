# Tera-Mod-Bunny-chu-
Turns your white and blue bunny mount into a pikachu theme
Tumblr for pics https://thetaylorswiftofmodding.tumblr.com/post/184978594925/tera-mount-mod-turns-your-blue-bunny-mount-into-a
